## ----include = FALSE, echo = FALSE, message = FALSE, warning = FALSE----------
knitr::opts_chunk$set(
  collapse = TRUE,
  comment = "#>"
)

## ----setup, message = FALSE---------------------------------------------------
library(dmcognigen)
library(dplyr)

## ----include=FALSE------------------------------------------------------------
# function to use to display formulas in this vignette.
vignette_equation <- function(.var_name) {
  htmltools::pre(
    gsub("\n  ", "\n", 
         gsub("^  ", "", get_from_calculations_table(.var_name, "equation")))
  )
}

# common text in examples
example1_text <- "All expected variables are provided:"
example2_text <- "All or some of expected variables are missing. In this case, the function will try to detect those missing variables from the parent environment:"

## -----------------------------------------------------------------------------
calculate_crcl(
  age = 50,
  scr = 1,
  sexf = 0,
  wtkg = 70
)

## -----------------------------------------------------------------------------
glimpse(dmcognigen_cov)

## -----------------------------------------------------------------------------
glimpse(dmcognigen_conc)

## ----echo=FALSE---------------------------------------------------------------
vignette_equation("crcl")

## -----------------------------------------------------------------------------
dmcognigen_cov %>% 
  mutate(
    CRCL = calculate_crcl(
      age = AGE,
      scr = SCR,
      sexf = SEXF,
      wtkg = WTKG
    )
  ) %>% 
  select(USUBJID, AGE, SCR, SEXF, WTKG, CRCL)

## -----------------------------------------------------------------------------
dmcognigen_cov %>% 
  mutate(
    CRCL = calculate_crcl()
  ) %>% 
  select(USUBJID, AGE, SCR, SEXF, WTKG, CRCL)

dmcognigen_cov %>% 
  mutate(
    CRCL = calculate_crcl(age = AGE)
  ) %>% 
  select(USUBJID, AGE, SCR, SEXF, WTKG, CRCL)

## ----echo=FALSE---------------------------------------------------------------
vignette_equation("crcl_peck")

## -----------------------------------------------------------------------------
dmcognigen_cov %>% 
  mutate(
    CRCLP = calculate_crcl_peck(
      age = AGE,
      crcl = CRCL,
      ibw = IBW,
      scr = SCR,
      sexf = SEXF,
      wtkg = WTKG
    )
  ) %>% 
  select(USUBJID, AGE, CRCL, IBW, SCR, SEXF, WTKG, CRCLP)

## -----------------------------------------------------------------------------
dmcognigen_cov %>% 
  mutate(
    CRCLP = calculate_crcl_peck()
  ) %>% 
  select(USUBJID, AGE, CRCL, IBW, SCR, SEXF, WTKG, CRCLP)

## ----echo=FALSE---------------------------------------------------------------
vignette_equation("bmi")

## -----------------------------------------------------------------------------
dmcognigen_cov %>% 
  mutate(
    BMI = calculate_bmi(
      htcm = HTCM,
      wtkg = WTKG 
    )
  ) %>% 
  select(USUBJID, HTCM, WTKG, BMI)

## -----------------------------------------------------------------------------
dmcognigen_cov %>% 
  mutate(
    BMI = calculate_bmi()
  ) %>% 
  select(USUBJID, HTCM, WTKG, BMI)

## ----echo=FALSE---------------------------------------------------------------
vignette_equation("bsa")

## -----------------------------------------------------------------------------
dmcognigen_cov %>% 
  mutate(
    BSA = calculate_bsa(
      htcm = HTCM, 
      wtkg = WTKG
    )
  ) %>% 
  select(USUBJID, HTCM, WTKG, BSA)

## -----------------------------------------------------------------------------
dmcognigen_cov %>% 
  mutate(
    BSA = calculate_bsa()
  ) %>% 
  select(USUBJID, HTCM, WTKG, BSA)

## ----echo=FALSE---------------------------------------------------------------
vignette_equation("lbm")

## -----------------------------------------------------------------------------
dmcognigen_cov %>% 
  mutate(
    LBM = calculate_lbm(
      htcm = HTCM,
      sexf = SEXF,
      wtkg = WTKG
    )
  ) %>% 
  select(USUBJID, HTCM, SEXF, WTKG, LBM)

## -----------------------------------------------------------------------------
dmcognigen_cov %>% 
  mutate(
    LBM = calculate_lbm()
  ) %>% 
  select(USUBJID, HTCM, SEXF, WTKG, LBM)

## ----echo=FALSE---------------------------------------------------------------
vignette_equation("ibw")

## -----------------------------------------------------------------------------
dmcognigen_cov %>% 
  mutate(
    IBW = calculate_ibw(
      htcm = HTCM,
      sexf = SEXF 
    )
  ) %>% 
  select(USUBJID, HTCM, SEXF, IBW)

## -----------------------------------------------------------------------------
dmcognigen_cov %>% 
  mutate(
    IBW = calculate_ibw()
  ) %>% 
  select(USUBJID, HTCM, SEXF, IBW)

## ----echo=FALSE---------------------------------------------------------------
vignette_equation("ibw_child")

## -----------------------------------------------------------------------------
dmcognigen_cov %>% 
  mutate(
    IBWCHILD = calculate_ibw_child(age = AGE, htcm = HTCM)
  ) %>% 
  select(USUBJID, AGE, HTCM, IBWCHILD)

## -----------------------------------------------------------------------------
dmcognigen_cov %>% 
  mutate(
    IBWCHILD = calculate_ibw_child()
  ) %>% 
  select(USUBJID, AGE, HTCM, IBWCHILD)

## ----echo=FALSE---------------------------------------------------------------
vignette_equation("egfr")

## -----------------------------------------------------------------------------
dmcognigen_cov %>% 
  mutate(
    EGFR = calculate_egfr(
      age = AGE,
      racen = RACEN,
      scr = SCR,
      sexf = SEXF
    )
  ) %>% 
  select(USUBJID, AGE, RACEN, SCR, SEXF, EGFR)

## -----------------------------------------------------------------------------
dmcognigen_cov %>% 
  mutate(
    EGFR = calculate_egfr()
  ) %>% 
  select(USUBJID, AGE, RACEN, SCR, SEXF, EGFR)

## ----echo=FALSE---------------------------------------------------------------
vignette_equation("egfr_child")

## -----------------------------------------------------------------------------
dmcognigen_cov %>% 
  mutate(
    EGFR_CHILD = calculate_egfr_child(
      age = AGE, 
      htcm = HTCM,
      scr = SCR,
      sexf = SEXF
    )
  ) %>% 
  select(USUBJID, AGE, HTCM, SCR, SEXF, EGFR_CHILD)

## -----------------------------------------------------------------------------
dmcognigen_cov %>% 
  mutate(
    EGFR_CHILD = calculate_egfr_child()
  ) %>% 
  select(USUBJID, AGE, HTCM, SCR, SEXF, EGFR_CHILD)

## ----echo=FALSE---------------------------------------------------------------
vignette_equation("rfcat")

## -----------------------------------------------------------------------------
dmcognigen_cov %>% 
  mutate(
    EGFR = calculate_egfr(
      age = AGE,
      racen = RACEN,
      scr = SCR,
      sexf = SEXF
    ),
    RFCAT = calculate_rfcat(egfr = EGFR)
  ) %>% 
  select(USUBJID, EGFR, RFCAT)

## -----------------------------------------------------------------------------
dmcognigen_cov %>% 
  mutate(
    RFCAT = calculate_rfcat()
  ) %>% 
  select(USUBJID, EGFR, RFCAT)

## ----echo=FALSE---------------------------------------------------------------
vignette_equation("tbilcat")

## -----------------------------------------------------------------------------
dmcognigen_cov %>% 
  mutate(
    TBILCAT = calculate_tbilcat(
      tbil = TBIL, 
      tbiluln = TBILULN
    )
  ) %>% 
  select(USUBJID, TBIL, TBILULN, TBILCAT)

## -----------------------------------------------------------------------------
dmcognigen_cov %>% 
  mutate(
    TBILCAT = calculate_tbilcat()
  ) %>% 
  select(USUBJID, TBIL, TBILULN, TBILCAT)

## ----echo=FALSE---------------------------------------------------------------
vignette_equation("astcat")

## -----------------------------------------------------------------------------
dmcognigen_cov %>% 
  mutate(
    ASTCAT = calculate_astcat(
      ast = AST, 
      astuln = ASTULN
    )
  ) %>% 
  select(USUBJID, AST, ASTULN, ASTCAT)

## -----------------------------------------------------------------------------
dmcognigen_cov %>% 
  mutate(
    ASTCAT = calculate_astcat()
  ) %>% 
  select(USUBJID, AST, ASTULN, ASTCAT)

## ----echo=FALSE---------------------------------------------------------------
vignette_equation("nciliv")

## -----------------------------------------------------------------------------
dmcognigen_cov %>% 
  mutate(
    NCILIV = calculate_nciliv(astcat = ASTCAT, tbilcat = TBILCAT)
  ) %>% 
  select(USUBJID, ASTCAT, TBILCAT, NCILIV)

## -----------------------------------------------------------------------------
dmcognigen_cov %>% 
  mutate(
    NCILIV = calculate_nciliv()
  ) %>% 
  select(USUBJID, ASTCAT, TBILCAT, NCILIV)

