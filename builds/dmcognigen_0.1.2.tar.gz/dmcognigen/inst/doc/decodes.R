## ----include = FALSE----------------------------------------------------------
knitr::opts_chunk$set(
  collapse = TRUE,
  comment = "#>"
)

## ----setup, message = FALSE---------------------------------------------------
library(dmcognigen)
library(dplyr)

data("dmcognigen_pk_requirements")
requirements <- dmcognigen_pk_requirements %>% 
  select(variable_name, variable_label, format_decode)

data("dmcognigen_cov")
cov <- dmcognigen_cov

data("dmcognigen_pk")
pk <- dmcognigen_pk

## ----echo=FALSE---------------------------------------------------------------
requirements %>% 
  filter(variable_name == "RFCAT") %>% 
  with(extract_decode_tbl(
    variable_name = variable_name,
    decode = format_decode
  ))

## ----echo=FALSE---------------------------------------------------------------
requirements %>% 
  filter(format_decode != "")

## ----echo=FALSE---------------------------------------------------------------
# print the variable names and the content of their decode
requirements %>% 
  filter(format_decode != "") %>% 
  rowwise() %>% 
  summarise(cat(paste0(
    variable_name, ":\n", format_decode, "\n\n"
  ))) %>% 
  invisible()

## -----------------------------------------------------------------------------
extract_decode_tbls(
  variable_name = requirements$variable_name,
  decode = requirements$format_decode
)

## -----------------------------------------------------------------------------
cov %>%
  cnt(RACEN, RACEC)

cov %>%
  extract_decode_tbls_from_data(
    lvl_to_lbl = list(RACEN = "RACEC")
  )

## -----------------------------------------------------------------------------
cov %>%
  extract_decode_tbls_from_data(
    lvl_to_lbl = list(
      # map individual variables
      SEXF = "SEXFC",
      RACEN = "RACEC",
      # map other lvl to lbl by removing CD at the end of variable names
      ~ stringr::str_remove(.x, "CD$")
    )
  )

## -----------------------------------------------------------------------------
cov %>%
  extract_decode_tbls_from_data(
    lvl_to_lbl = list(
      RACEN = "RACE"
    )
  )

## -----------------------------------------------------------------------------
cov %>%
  extract_decode_tbls_from_data(
    lvl_to_lbl = list(
      RACE = "RACEC"
    )
  )

## -----------------------------------------------------------------------------
tibble::tribble(
  ~var, ~lvl, ~lbl,
  "RACEN", 1, "White/Caucasian",
  "RACEN", 2, "Black/African American",
  "RACEN", 3, "Asian",
  "RACEN", 4, "American Indian or Alaska Native",
  
  "SEXF",  0, "Male",
  "SEXF",  1, "Female"
  ) %>% 
  split(~ var) %>% 
  as_decode_tbls()

## -----------------------------------------------------------------------------
pk_numeric <- pk %>% 
  select(where(is.numeric))

## -----------------------------------------------------------------------------
pk_numeric %>% 
  set_decode_factors(requirements) %>% 
  cnt(RACEN, SEXF, n_distinct_vars = ID)

## -----------------------------------------------------------------------------
pk_numeric %>% 
  select(all_of(stationary_variables(., ID))) %>% 
  set_decode_factors(requirements) %>% 
  cnt(across(where(is.factor)), n_distinct_vars = ID)

## -----------------------------------------------------------------------------
pk_numeric %>% 
  set_decode_factors(
    decode_tbls = requirements, 
    new_names = list(
      "{var}FCT",
      RACEN = "RACEN", 
      SEXF = "SEXFC" 
    )
  ) %>% 
  cnt(RACEN, SEXFC, RFCATFCT, n_distinct_vars = ID)

## -----------------------------------------------------------------------------
pk_numeric_with_label_vars <- pk_numeric %>% 
  join_decode_labels(requirements)

## -----------------------------------------------------------------------------
pk_numeric %>% 
  select(ID, RACEN, SEXF) %>% 
  join_decode_labels(requirements, lvl_to_lbl = list(RACEN = "RACEC", "{var}C")) %>% 
  cnt(RACEN, RACEC, SEXF, SEXFC, n_distinct_vars = ID)

## -----------------------------------------------------------------------------
pk %>% 
  select(ID, RACEN, RACEC, SEXF) %>% 
  join_decode_labels(requirements, lvl_to_lbl = list(RACEN = "RACEC", "{var}C")) %>% 
  cnt(RACEN, RACEC, SEXF, SEXFC, n_distinct_vars = ID)

## -----------------------------------------------------------------------------
pk %>% 
  select(ID, RACEC, SEXFC) %>% 
  join_decode_levels(requirements, lvl_to_lbl = list(RACEN = "RACEC", "{var}C")) %>% 
  cnt(RACEN, RACEC, SEXF, SEXFC, n_distinct_vars = ID)

