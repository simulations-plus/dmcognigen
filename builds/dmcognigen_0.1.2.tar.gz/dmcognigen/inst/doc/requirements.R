## ----include = FALSE----------------------------------------------------------
knitr::opts_chunk$set(
  collapse = TRUE,
  comment = "#>"
)

## ----setup, message = FALSE---------------------------------------------------
library(dmcognigen)
library(dplyr)

data("dmcognigen_pk_requirements")

data("dmcognigen_cov")
data("dmcognigen_pk")

## ----echo=FALSE---------------------------------------------------------------
tibble::tribble(
  ~name,             ~description,
  "variable_name",   "Variable Name",
  "variable_label",  "Variable Label",
  "pk_ard",          "Whether the variable is in the Analysis Ready Dataset",
  "pk_mif",          "Whether the variable is in the Model Input File",
  "format_decode",   "Pairs of (generally) numeric values and descriptions"
) %>% 
  print.data.frame(row.names = FALSE)

## -----------------------------------------------------------------------------
asmbdat_directory <- file.path(tempdir(), "asmbdat")
asmbdat_directory

## ----include=FALSE------------------------------------------------------------
# write the file to tmp a few times, to demonstrate the capture of the date in the filename
dir.create(asmbdat_directory, showWarnings = FALSE)

# pretend that a long time ago, we didn't name the specs tab
openxlsx::write.xlsx(
  dmcognigen_pk_requirements,
  file = file.path(asmbdat_directory, "data-requirements-2019-12-01.xlsx")
)

openxlsx::write.xlsx(
  list(specs = dmcognigen_pk_requirements),
  file = file.path(asmbdat_directory, "data-requirements-2020-01-01.xlsx")
)

# include additional sheet (empty)
openxlsx::write.xlsx(
  list(specs = dmcognigen_pk_requirements, unit_conversions = data.frame()),
  file = file.path(asmbdat_directory, "data-requirements-2020-01-10.xlsx")
)

# include another additional sheet (empty)
# this is intended to be the latest version.
openxlsx::write.xlsx(
  list(specs = dmcognigen_pk_requirements, unit_conversions = data.frame(), discussions = data.frame()),
  file = file.path(asmbdat_directory, paste0("data-requirements-", lubridate::today(), ".xlsx"))
)

# copy of the requirements for QC purposes
openxlsx::write.xlsx(
  list(specs = dmcognigen_pk_requirements, unit_conversions = data.frame(), discussions = data.frame(), qc_findings = data.frame()),
  file = file.path(asmbdat_directory, paste0("qc-data-requirements-", lubridate::today(), ".xlsx"))
)

# empty docx file to demonstrate including docx in searches
file.create(file.path(asmbdat_directory, "legacy-data-requirements-2000-01-01.docx"))

## ----echo=FALSE---------------------------------------------------------------
fs::dir_tree(asmbdat_directory)

## -----------------------------------------------------------------------------
available_requirements_table(
  path = asmbdat_directory,
  pattern = "req"
) %>% 
  select(-c(created, modified)) %>% 
  print.data.frame()

## -----------------------------------------------------------------------------
available_requirements_table(
  path = asmbdat_directory,
  pattern = "req",
  sheet = NULL
) %>%
  select(-c(created, modified)) %>% 
  print.data.frame()

## -----------------------------------------------------------------------------
available_requirements_table(
  path = asmbdat_directory,
  pattern = "req",
  sheet = NULL,
  drop_qc = FALSE
) %>% 
  select(-c(created, modified)) %>% 
  print.data.frame()

## -----------------------------------------------------------------------------
requirements <- read_requirements(asmbdat_directory)
glimpse(requirements)

## -----------------------------------------------------------------------------
requirements_pk_mif <- read_requirements(
  asmbdat_directory,
  subset = pk_mif == "x"
)
glimpse(requirements_pk_mif)

## -----------------------------------------------------------------------------
requirements_pk_mif_with_as <- as_requirements(
  as.data.frame(requirements_pk_mif)
)
identical(requirements_pk_mif_with_as, requirements_pk_mif)

## -----------------------------------------------------------------------------
attr(requirements, "decode_tbls")

## -----------------------------------------------------------------------------
dmcognigen_pk %>% 
  select(USUBJID, RACEN, SEXF) %>% 
  join_decode_labels(dmcognigen_pk_requirements, lvl_to_lbl = list(RACEN = "RACEC", "{var}C")) %>% 
  cnt(RACEN, RACEC, SEXF, SEXFC, n_distinct_vars = USUBJID)

## -----------------------------------------------------------------------------
dmcognigen_cov %>% 
  set_decode_factors(requirements, new_names = list(RACEN = "RACEN", "{var}FCT")) %>% 
  cnt(RACEN, across(ends_with("FCT")), n_cumulative = FALSE)

## -----------------------------------------------------------------------------
attr(requirements, "labels_named_list") %>% 
  head()

## ----include=FALSE------------------------------------------------------------
empty_labels <- character(ncol(dmcognigen_cov)) %>% 
  purrr::set_names(names(dmcognigen_cov))

dmcognigen_cov_labels_removed <- dmcognigen_cov %>% 
  set_labels(labels = empty_labels) %>% 
  select(STUDYID, USUBJID, RACEN)

## -----------------------------------------------------------------------------
dmcognigen_cov_labels_removed %>% 
  str()

# apply the labels
dmcognigen_cov_labels_removed %>% 
  set_labels(labels = requirements) %>% 
  str()

