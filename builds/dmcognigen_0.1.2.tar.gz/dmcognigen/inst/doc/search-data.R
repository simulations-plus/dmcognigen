## ----include = FALSE----------------------------------------------------------
knitr::opts_chunk$set(
  collapse = TRUE,
  comment = "#>"
)

## ----setup, message = FALSE---------------------------------------------------
library(dmcognigen)
library(stringr)
library(dplyr)

## -----------------------------------------------------------------------------
pharmaversesdtm_data_env <- new.env()

data(
  list = data(package = "pharmaversesdtm")$results[ , "Item"], 
  package = "pharmaversesdtm", 
  envir = pharmaversesdtm_data_env
)

## -----------------------------------------------------------------------------
search_environment_data(
  regex("XANOMELINE", ignore_case = TRUE),
  envir = pharmaversesdtm_data_env
)

## -----------------------------------------------------------------------------
search_environment_data(
  regex("XANOMELINE", ignore_case = TRUE),
  envir = pharmaversesdtm_data_env
) %>% 
  cnt_search_result(
    n_distinct_vars = "USUBJID"
  )

## -----------------------------------------------------------------------------
search_environment_data(
  regex("STUDYID", ignore_case = TRUE),
  envir = pharmaversesdtm_data_env
) %>% 
  cnt_search_result(
    n_distinct_vars = "USUBJID"
  ) %>% 
  bind_rows(.id = "dataset")

## -----------------------------------------------------------------------------
search_environment_data(
  regex("cancer", ignore_case = TRUE),
  envir = pharmaversesdtm_data_env
) %>% 
  cnt_search_result(
    n_distinct_vars = "USUBJID",
    ignore_df_names = c("ae", "ae_ophtha"),
    extra_vars = c("STUDYID")
  )

