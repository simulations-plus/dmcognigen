# dmcognigen

<!-- badges: start -->

[![R-CMD-check](https://github.com/simulations-plus/dmcognigen/actions/workflows/R-CMD-check.yaml/badge.svg)](https://github.com/simulations-plus/dmcognigen/actions/workflows/R-CMD-check.yaml)

<!-- badges: end -->

# Overview

`dmcognigen` provides functions for data management tasks at the Clinical Pharmacology and Pharmacometrics (CPP) business unit of Simulations Plus, Inc.

Install it with:
```r
remotes::install_github("simulations-plus/dmcognigen")
```

Load it with:
```r
library(dmcognigen)
```

# Functionality

## Count Observations and Unique Values by Group

- The function expected to be used most frequently in this package is the `cnt()` function.
- `cnt()` is an extension of `dplyr::count()` intended to count the number of distinct occurrences of variables within some group. For example, we commonly `cnt(.data, STUDYID, n_distinct_vars = USUBJID)` to count the number of records within each STUDYID along with the number of unique subjects (USUBJID) within each STUDYID.

## Calculate Standard Variables

- See full details in the [Calculations vignette](https://simulations-plus.github.io/dmcognigen/articles/calculations.html).
- Use the `calculate_*()` family of functions to apply standard equations.

## Read and Leverage Data Requirements

- See full details in the [Data Requirements vignette](https://simulations-plus.github.io/dmcognigen/articles/requirements.html).
- Check which data requirement files are available with `available_requirements_table()` and import data requirements with `read_requirements()`.
- Use attributes of requirements to apply characteristics defined in data requirements to a dataset.
  - The `"decode_tbls"` attribute can be utilized within `join_decode_labels()` or `join_decode_levels()`.
  - The `"labels_named_list"` attribute can be utilized within `set_labels()`.

## Interact with Decodes

- See full details in the [Decode Tables vignette](https://simulations-plus.github.io/dmcognigen/articles/decodes.html).
- Extract decodes from vectors with `extract_decode_tbls()`.
- Extract decodes from a dataset with `extract_decode_tbls_from_data()`.
- Merge decodes with `join_decode_labels()` or `join_decode_levels()`.
- Create factor variables with `set_decode_factors()`.

## Search Datasets

- Find datasets where variables exist with `in_which()`.
- Search for patterns in variable names, variable labels, and variable content across all datasets in an environment with `search_environment_data()` then summarize the results with `cnt_search_result()`.
