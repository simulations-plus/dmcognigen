# dmcognigen

# Overview

`dmcognigen` provides functions for data management tasks at Cognigen.

Load it with:
```r
library(dmcognigen)
```

# Functionality
