## ----include = FALSE, echo = FALSE, message = FALSE, warning = FALSE----------
knitr::opts_chunk$set(
  collapse = TRUE,
  comment = "#>"
)

## ----message=FALSE------------------------------------------------------------
library(dmcognigen)
library(dplyr)

## -----------------------------------------------------------------------------
dmcognigen_cov %>%
  mutate(
    CRCL = calculate_crcl(
      age = AGE,
      wtkg = WTKG,
      scr = SCR,
      sexf = SEXF
    )
  ) %>%
  select(USUBJID, AGE, WTKG, SCR, SEXF, CRCL)

## -----------------------------------------------------------------------------
glimpse(dmcognigen_cov)

## -----------------------------------------------------------------------------
glimpse(dmcognigen_conc)

## ----include = FALSE----------------------------------------------------------
example1_text <- "All expected variables are provided:"

example2_text <- "All or some of expected variables are missing. In this case, the function will try to detect those missing variables from the parent environment:"

## -----------------------------------------------------------------------------
dmcognigen_cov %>% 
  mutate(
    CRCL = calculate_crcl(
      age = AGE,
      wtkg = WTKG,
      scr = SCR,
      sexf = SEXF
    )
  ) %>% 
  select(USUBJID, AGE, WTKG, SCR, SEXF, CRCL)

## -----------------------------------------------------------------------------
dmcognigen_cov %>% 
  mutate(
    CRCL = calculate_crcl()
  ) %>% 
  select(USUBJID, AGE, WTKG, SCR, SEXF, CRCL)

dmcognigen_cov %>% 
  mutate(
    CRCL = calculate_crcl(age = AGE)
  ) %>% 
  select(USUBJID, AGE, WTKG, SCR, SEXF, CRCL)

## -----------------------------------------------------------------------------
dmcognigen_cov %>% 
  mutate(
    CRCLP = calculate_crcl_peck(
      age = AGE,
      wtkg = WTKG,
      crcl = CRCL,
      ibw = IBW,
      scr = SCR,
      sexf = SEXF
    )
  ) %>% 
  select(USUBJID, AGE, WTKG, CRCL, IBW, SCR, SEXF, CRCLP)

## -----------------------------------------------------------------------------
dmcognigen_cov %>% 
  mutate(
    CRCLP = calculate_crcl_peck()
  ) %>% 
  select(USUBJID, AGE, WTKG, CRCL, IBW, SCR, SEXF, CRCLP)

## -----------------------------------------------------------------------------
dmcognigen_cov %>% 
  mutate(
    BMI = calculate_bmi(
      wtkg = WTKG, 
      htcm = HTCM
    )
  ) %>% 
  select(USUBJID, WTKG, HTCM, BMI)

## -----------------------------------------------------------------------------
dmcognigen_cov %>% 
  mutate(
    BMI = calculate_bmi()
  ) %>% 
  select(USUBJID, WTKG, HTCM, BMI)

## -----------------------------------------------------------------------------
dmcognigen_cov %>% 
  mutate(
    BSA = calculate_bsa(
      htcm = HTCM, 
      wtkg = WTKG
    )
  ) %>% 
  select(USUBJID, HTCM, WTKG, BSA)

## -----------------------------------------------------------------------------
dmcognigen_cov %>% 
  mutate(
    BSA = calculate_bsa()
  ) %>% 
  select(USUBJID, HTCM, WTKG, BSA)

## -----------------------------------------------------------------------------
dmcognigen_cov %>% 
  mutate(
    LBM = calculate_lbm(
      sexf = SEXF,
      wtkg = WTKG,
      htcm = HTCM
    )
  ) %>% 
  select(USUBJID, SEXF, WTKG, HTCM, LBM)

## -----------------------------------------------------------------------------
dmcognigen_cov %>% 
  mutate(
    LBM = calculate_lbm()
  ) %>% 
  select(USUBJID, SEXF, WTKG, HTCM, LBM)

## -----------------------------------------------------------------------------
dmcognigen_cov %>% 
  mutate(
    IBW = calculate_ibw(
      sexf = SEXF, 
      htcm = HTCM
    )
  ) %>% 
  select(USUBJID, SEXF, HTCM, IBW)

## -----------------------------------------------------------------------------
dmcognigen_cov %>% 
  mutate(
    IBW = calculate_ibw()
  ) %>% 
  select(USUBJID, SEXF, HTCM, IBW)

## -----------------------------------------------------------------------------
dmcognigen_cov %>% 
  mutate(
    IBWCHILD = calculate_ibw_child(htcm = HTCM)
  ) %>% 
  select(USUBJID, HTCM, IBWCHILD)

## -----------------------------------------------------------------------------
dmcognigen_cov %>% 
  mutate(
    IBWCHILD = calculate_ibw_child()
  ) %>% 
  select(USUBJID, HTCM, IBWCHILD)

## -----------------------------------------------------------------------------
dmcognigen_cov %>% 
  mutate(
    EGFR = calculate_egfr(
      scr = SCR,
      age = AGE,
      sexf = SEXF,
      racen = RACEN
    )
  ) %>% 
  select(USUBJID, SCR, AGE, SEXF, RACEN, EGFR)

## -----------------------------------------------------------------------------
dmcognigen_cov %>% 
  mutate(
    EGFR = calculate_egfr()
  ) %>% 
  select(USUBJID, SCR, AGE, SEXF, RACEN, EGFR)

## -----------------------------------------------------------------------------
dmcognigen_cov %>% 
  mutate(
    EGFR_CHILD = calculate_egfr_child(
      htcm = HTCM,
      scr = SCR,
      age = AGE, 
      sexf = SEXF
    )
  ) %>% 
  select(USUBJID, HTCM, SCR, AGE, SEXF, EGFR_CHILD)

## -----------------------------------------------------------------------------
dmcognigen_cov %>% 
  mutate(
    EGFR_CHILD = calculate_egfr_child()
  ) %>% 
  select(USUBJID, HTCM, SCR, AGE, SEXF, EGFR_CHILD)

## -----------------------------------------------------------------------------
dmcognigen_cov %>% 
  mutate(
    EGFR = calculate_egfr(
      scr = SCR,
      age = AGE,
      sexf = SEXF,
      racen = RACEN
    ),
    RFCAT = calculate_rfcat(egfr = EGFR)
  ) %>% 
  select(USUBJID, EGFR, RFCAT)

## -----------------------------------------------------------------------------
dmcognigen_cov %>% 
  mutate(
    RFCAT = calculate_rfcat()
  ) %>% 
  select(USUBJID, EGFR, RFCAT)

## -----------------------------------------------------------------------------
dmcognigen_cov %>% 
  mutate(
    TBILCAT = calculate_tbilcat(
      tbil = TBIL, 
      tbiluln = TBILULN
    )
  ) %>% 
  select(USUBJID, TBIL, TBILULN, TBILCAT)

## -----------------------------------------------------------------------------
dmcognigen_cov %>% 
  mutate(
    TBILCAT = calculate_tbilcat()
  ) %>% 
  select(USUBJID, TBIL, TBILULN, TBILCAT)

## -----------------------------------------------------------------------------
dmcognigen_cov %>% 
  mutate(
    ASTCAT = calculate_astcat(
      ast = AST, 
      astuln = ASTULN
    )
  ) %>% 
  select(USUBJID, AST, ASTULN, ASTCAT)

## -----------------------------------------------------------------------------
dmcognigen_cov %>% 
  mutate(
    ASTCAT = calculate_astcat()
  ) %>% 
  select(USUBJID, AST, ASTULN, ASTCAT)

## -----------------------------------------------------------------------------
dmcognigen_cov %>% 
  mutate(
    NCILIV = calculate_nciliv(tbilcat = TBILCAT, astcat = ASTCAT)
  ) %>% 
  select(USUBJID, TBILCAT, ASTCAT, NCILIV)

## -----------------------------------------------------------------------------
dmcognigen_cov %>% 
  mutate(
    NCILIV = calculate_nciliv()
  ) %>% 
  select(USUBJID, TBILCAT, ASTCAT, NCILIV)

