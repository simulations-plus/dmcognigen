## ----include = FALSE----------------------------------------------------------
knitr::opts_chunk$set(
  collapse = TRUE,
  comment = "#>"
)

## ----setup--------------------------------------------------------------------
library(dmcognigen)
library(dplyr)

## ----echo=FALSE---------------------------------------------------------------
reqs_to_write <- dmcognigen:::example_requirements

reqs_to_write

## ----echo=FALSE---------------------------------------------------------------
tibble::tribble(
  ~name,             ~description,
  "variable_name",   "Variable Name",
  "variable_label",  "Variable Label",
  "pk_ard",          "Whether to keep the variable in the Analysis Ready Dataset",
  "pk_mif",          "Whether to keep the variable in the Model Input File",
  "format_decode",   "Name/Value pairs of decodes, also referred to as formats"
) %>% 
  print.data.frame()

## -----------------------------------------------------------------------------
asmbdat_directory <- file.path(tempdir(), "asmbdat")
asmbdat_directory

## ----include=FALSE------------------------------------------------------------
# write the file to tmp a few times, to demonstrate the capture of the date in the filename
dir.create(asmbdat_directory, showWarnings = FALSE)

# pretend that a long time ago, we didn't name the specs tab
openxlsx::write.xlsx(
  reqs_to_write,
  file = file.path(asmbdat_directory, "data-requirements-2019-12-01.xlsx")
)

openxlsx::write.xlsx(
  list(specs = reqs_to_write),
  file = file.path(asmbdat_directory, "data-requirements-2020-01-01.xlsx")
)

# include additional sheet (empty)
openxlsx::write.xlsx(
  list(specs = reqs_to_write, unit_conversions = data.frame()),
  file = file.path(asmbdat_directory, "data-requirements-2020-01-10.xlsx")
)

# include another additional sheet (empty)
openxlsx::write.xlsx(
  list(specs = reqs_to_write, unit_conversions = data.frame(), discussions = data.frame()),
  file = file.path(asmbdat_directory, "data-requirements-2020-01-20.xlsx")
)

# copy of the requirements for QC purposes
openxlsx::write.xlsx(
  list(specs = reqs_to_write, unit_conversions = data.frame(), discussions = data.frame(), qc_findings = data.frame()),
  file = file.path(asmbdat_directory, "qc-data-requirements-2020-01-20.xlsx")
)

## ----echo=FALSE---------------------------------------------------------------
# list the files, preferably with fs::dir_tree
if(requireNamespace("fs", quietly = TRUE)) {
  fs::dir_tree(asmbdat_directory)
} else {
  list.files(asmbdat_directory)
}

## -----------------------------------------------------------------------------
available_requirements_table(
  path = asmbdat_directory,
  pattern = "req"
) %>% 
  print.data.frame()

## -----------------------------------------------------------------------------
available_requirements_table(
  path = asmbdat_directory,
  pattern = "req",
  sheet = NULL
) %>% 
  print.data.frame()

## -----------------------------------------------------------------------------
available_requirements_table(
  path = asmbdat_directory,
  pattern = "req",
  sheet = NULL,
  drop_qc = FALSE
) %>% 
  print.data.frame()

## -----------------------------------------------------------------------------
requirements <- read_requirements(asmbdat_directory)
glimpse(requirements)

## -----------------------------------------------------------------------------
requirements_pk_mif <- read_requirements(
  asmbdat_directory,
  subset = pk_mif == "x"
)
glimpse(requirements_pk_mif)

## -----------------------------------------------------------------------------
attr(requirements, "decode_tbls")

## -----------------------------------------------------------------------------
extracted_requirements_decode_tbls <- extract_decode_tbls(
  variable_name = requirements$variable_name, 
  decode = requirements$format_decode
)
identical(attr(requirements, "decode_tbls"), extracted_requirements_decode_tbls)

## -----------------------------------------------------------------------------
# shared variables
variables_with_decodes <- intersect(names(extracted_requirements_decode_tbls), names(dmcognigen_cov))
variables_with_decodes

## -----------------------------------------------------------------------------
dmcognigen_cov %>% 
  select(USUBJID, RACEN, SEXF) %>% 
  join_decode_labels(requirements, lvl_to_lbl = list(RACEN = "RACEC", "{var}C")) %>% 
  cnt(RACEN, RACEC, SEXF, SEXFC)

## -----------------------------------------------------------------------------
attr(requirements, "labels_named_list")

## ----include=FALSE------------------------------------------------------------
empty_labels <- character(ncol(dmcognigen_cov)) %>% 
  purrr::set_names(names(dmcognigen_cov))

dmcognigen_cov_labels_removed <- dmcognigen_cov %>% 
  set_labels(labels = empty_labels) %>% 
  select(STUDYID, USUBJID, RACEN)

## -----------------------------------------------------------------------------
dmcognigen_cov_labels_removed %>% 
  str()

# apply the labels
dmcognigen_cov_labels_removed %>% 
  set_labels(labels = requirements) %>% 
  str()

