## ----include = FALSE----------------------------------------------------------
knitr::opts_chunk$set(
  collapse = TRUE,
  comment = "#>"
)

## ----setup--------------------------------------------------------------------
library(dmcognigen)
library(dplyr)

## ----echo=FALSE---------------------------------------------------------------
# copied content from vignettes/requirements.Rmd
reqs_to_write <- dmcognigen:::example_requirements

example_decodes <- reqs_to_write %>% 
  select(variable_name, variable_label, format_decode)

## ----echo=FALSE---------------------------------------------------------------
example_decodes %>% 
  filter(variable_name == "AGECAT") %>% 
  with(extract_decode_tbl(
    variable_name = variable_name,
    decode = format_decode
  ))

## ----echo=FALSE---------------------------------------------------------------
example_decodes

## ----echo=FALSE---------------------------------------------------------------
# print the variable names and the content of their decode
example_decodes %>% 
  filter(!is.na(format_decode)) %>% 
  rowwise() %>% 
  summarise(cat(paste0(
    variable_name, ":\n", format_decode, "\n\n"
  ))) %>% 
  invisible()

