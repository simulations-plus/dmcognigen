## ----include = FALSE----------------------------------------------------------
knitr::opts_chunk$set(
  collapse = TRUE,
  comment = "#>"
)

## ----setup--------------------------------------------------------------------
library(dmcognigen)
library(dplyr)

## ----echo=FALSE---------------------------------------------------------------
# copied content from vignettes/requirements.Rmd
reqs_to_write <- tibble::tribble(
  ~variable_name, ~variable_label,             ~pk_ard, ~pk_mif, ~format_decode, 
  "STUDYID",      "Study Identifier",          "x",     NA,      NA,
  "USUBJID",      "Unique Subject Identifier", "x",     NA,      NA,
  "ID",           "Subject ID",                "x",     "x",     NA,
  "AGECAT",       "Baseline Age Category",     "x",     "x",     "1=18-50\n2=51-69\n3=70+",
  "RACEN",        "Race",                      "x",     "x",     "1=White/Caucasian\n2=Black/African American\n3=Asian-Japanese\n4=Asian-Korean\n5=Asian-other\n6=American Indian or Alaska Native\n7=Native Hawaiian or Other Pacific Islander\n8=Other",
  "SEXF",         "Sex",                       "x",     "x",     "0=Male\n1=Female",
  "FED",          "Fed",                       "x",     "x",     "0=Fasted\n1=Fed"
)

example_decodes <- reqs_to_write %>% 
  select(variable_name, variable_label, format_decode)

## ----echo=FALSE---------------------------------------------------------------
example_decodes %>% 
  filter(variable_name == "AGECAT") %>% 
  with(extract_decode_tbl(
    variable_name = variable_name,
    decode = format_decode
  ))

## ----echo=FALSE---------------------------------------------------------------
example_decodes

## ----echo=FALSE---------------------------------------------------------------
# print the variable names and the content of their decode
example_decodes %>% 
  filter(!is.na(format_decode)) %>% 
  rowwise() %>% 
  summarise(cat(paste0(
    variable_name, ":\n", format_decode, "\n\n"
  ))) %>% 
  invisible()

