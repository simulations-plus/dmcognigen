## ----include = FALSE----------------------------------------------------------
knitr::opts_chunk$set(
  collapse = TRUE,
  comment = "#>"
)

## ----setup--------------------------------------------------------------------
library(dmcognigen)
library(dplyr)

## ----echo=FALSE---------------------------------------------------------------
example_decodes <- dmcognigen:::example_requirements %>% 
  select(variable_name, variable_label, format_decode)

## ----echo=FALSE---------------------------------------------------------------
example_decodes %>% 
  filter(variable_name == "AGECAT") %>% 
  with(extract_decode_tbl(
    variable_name = variable_name,
    decode = format_decode
  ))

## ----echo=FALSE---------------------------------------------------------------
example_decodes

## ----echo=FALSE---------------------------------------------------------------
# print the variable names and the content of their decode
example_decodes %>% 
  filter(!is.na(format_decode)) %>% 
  rowwise() %>% 
  summarise(cat(paste0(
    variable_name, ":\n", format_decode, "\n\n"
  ))) %>% 
  invisible()

## -----------------------------------------------------------------------------
extract_decode_tbls(
  variable_name = example_decodes$variable_name,
  decode = example_decodes$format_decode
)

## -----------------------------------------------------------------------------
dmcognigen_cov %>%
  cnt(RACEN, RACE)

dmcognigen_cov %>%
  extract_decode_tbls_from_data(
    lvl_to_lbl = c("RACEN" = "RACE")
  )

## -----------------------------------------------------------------------------
dmcognigen_cov %>%
  extract_decode_tbls_from_data(
    lvl_to_lbl = c(
      # map individual variables
      "SEXF" = "SEXFC",
      "RACEN" = "RACE",
      # by default map lvl to lbl by removing CD at the end of variable names
      ~ stringr::str_remove(.x, "CD$")
    )
  )

