library(testthat)
library(dmcognigen)

test_check("dmcognigen")
