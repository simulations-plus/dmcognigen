# print methods execute

    Code
      decode_tbl(complete_decode_tbl)
    Message
      
      -- SEXF --
      
      0=Male
      1=Female

# empty decode_tbl has no print output

    Code
      decode_tbl()

# printed decode_tbl is consistently arranged

    Code
      decode_tbl(complete_decode_tbl)
    Message
      
      -- SEXF --
      
      0=Male
      1=Female

---

    Code
      decode_tbl(complete_decode_tbl_different_order)
    Message
      
      -- SEXF --
      
      0=Male
      1=Female

