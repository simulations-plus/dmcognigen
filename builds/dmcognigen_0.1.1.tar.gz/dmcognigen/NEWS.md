# dmcognigen 0.1.1

* Fixed bug in `read_requirements()` where the file with the oldest date was selected instead of the most recent date. 
* Updated print method for `decode_tbls` so decode tables are consistently arranged.
* Added new functions `search_environment_data()` and `cnt_search_result()` for searching dataset contents, variable names, and variable labels.

# dmcognigen 0.1.0

* Added a `NEWS.md` file to track changes to the package.
